import 'package:e9_report/signin.dart';
import 'package:e9_report/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key, this.title}) : super(key: key);

  final String? title;

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.blue,
          shadowColor: Colors.transparent,
          automaticallyImplyLeading: true,
          //leading: IconButton(onPressed: () {}, icon: Icon(Icons.arrow_back)),
        ),
        body: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              signUpForm(context),
              hotLine(),
            ],
          ),
        ),
      ),
    );
  }
}

Widget signUpForm(BuildContext context) => Expanded(
      child: SingleChildScrollView(
        child: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset('images/logo.png', width: 200, height: 200),
              const TextFieldNameBorder('Họ và tên'),
              const SizedBox(height: 12),
              const TextFieldNumberBorder('Số điện thoại'),
              const SizedBox(height: 16),
              const TextFieldPasswordBorder('Mật khẩu'),
              const SizedBox(height: 16),
              ButtonReport(
                text: 'Đăng ký',
                width: 200,
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ]),
      ),
    );
