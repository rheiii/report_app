import 'dart:html';
import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: true,
          title: const Text('Liên hệ'),
        ),
        body: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            contactDetails(),
            const SizedBox(height: 16),
            contactActions(),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const TextFieldTopLabelBorder('Nội dung phản hồi'),
                  const SizedBox(height: 16),
                  ButtonReport(
                    text: 'Gửi',
                    width: double.infinity,
                    onPressed: () {},
                  ),
                ],
              ),
            )
          ]),
        ),
      ),
    );
  }

  Widget contactDetails() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: RichText(
        text: const TextSpan(
            style: TextStyle(fontSize: 16, height: 1.6),
            children: [
              TextSpan(
                  text: 'Địa chỉ: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: 'Vietnam\n'),
              TextSpan(
                  text: 'Hotline: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '0944556677 \n'),
              TextSpan(
                  text: 'Email: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: 'hoanguyen@mail.com'),
            ]),
      ),
    );
  }

  Widget contactActions() {
    return GridView(
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 2,
        ),
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.symmetric(
                    horizontal:
                        BorderSide(width: 1, color: Colors.grey.shade400))),
            alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Column(children: const [
              Icon(Icons.mail, color: Colors.blue),
              Text(
                'Gửi email',
                style: TextStyle(fontSize: 16),
              ),
            ]),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border.all(width: 1, color: Colors.grey.shade400)),
            alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              const Icon(Icons.phone, color: Colors.blue),
              const Text(
                'Gọi điện',
                style: TextStyle(fontSize: 16),
              ),
            ]),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border.symmetric(
                    horizontal:
                        BorderSide(width: 1, color: Colors.grey.shade400))),
            //alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Center(
              child: Column(children: [
                const Icon(Icons.chat, color: Colors.blue),
                const Text(
                  'Chat',
                  style: const TextStyle(fontSize: 16),
                ),
              ]),
            ),
          ),
        ]
        // [
        //   contactActionsItem(Icons.mail, 'Gửi email'),
        //   contactActionsItem(Icons.phone, 'Gọi điện'),
        //   contactActionsItem(Icons.chat, 'Chat'),
        // ],
        );
  }

//   Widget contactActionsItem(IconData icon, String text) {
//     return Container(
//       width: double.infinity,
//       decoration: BoxDecoration(
//         border: Border.all(width: 1, color: Colors.grey),
//       ),
//       alignment: Alignment.center,
//       padding: EdgeInsets.all(12),
//       child: Column(children: [
//         Icon(icon),
//         Text(
//           text,
//           style: TextStyle(fontSize: 16),
//         ),
//       ]),
//     );
//   }
}
