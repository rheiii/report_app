import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: true,
          title: const Text('Tài khoản'),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              avatarEdit(),
              const SizedBox(height: 16),
              const TextFieldNameBorder('Họ và tên'),
              const SizedBox(height: 16),
              const TextFieldBorder('Ngày sinh'),
              const SizedBox(height: 16),
              const TextFieldBorder('Địa chỉ'),
              const SizedBox(height: 16),
              const TextFieldNumberBorder('Số điện thoại'),
              const SizedBox(height: 16),
              const TextFieldEmailBorder('Email'),
              const SizedBox(height: 16),
              ButtonReport(
                text: 'Lưu',
                width: double.infinity,
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget avatarEdit() => Stack(children: [
        const CircleAvatar(
          radius: 40,
          backgroundImage: AssetImage('images/user1.png'),
        ),
        Positioned(
            bottom: 2,
            right: 2,
            child: Container(
              width: 28,
              height: 28,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.blue,
              ),
              child: const Icon(
                Icons.photo_camera,
                size: 16,
                color: Colors.white,
              ),
            )),
      ]);
}
