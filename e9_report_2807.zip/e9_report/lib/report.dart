import 'dart:html';
import 'package:e9_report/model.dart';
import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({Key? key}) : super(key: key);

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  final photos = <String>[];
  final String addphoto = ('images/add-photo.png');

  @override
  void initState() {
    const String photo1 = ('/images/issue2a.png');
    const String photo2 = ('/images/issue2b.png');
    const String photo3 = ('/images/issue2c.png');
    const String photo4 = ('/images/issue4a.jpg');
    const String photo5 = ('/images/issue4b.jpg');

    photos.addAll([photo1, photo2, photo3, photo4, photo5, addphoto]);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: true,
          title: const Text('Báo cáo'),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const TextFieldBorder('Tiêu đề'),
              const SizedBox(height: 12),
              const TextFieldLargeBorder('Nội dung'),
              uploadPhoto(),
              const SizedBox(height: 8),
              ButtonReport(
                text: 'Lưu',
                width: double.infinity,
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget uploadPhoto() {
    var crossAxisCount = 4;
    return GridView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        childAspectRatio: 1.6666,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemBuilder: (context, index) {
        final photo = photos[index];
        return uploadPhotoItem(photo);
      },
      itemCount: photos.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
    );
  }

  Widget uploadPhotoItem(String photo) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage(photo),
          fit: BoxFit.cover,
        ),
        borderRadius: BorderRadius.circular(4),
      ),

      height: 162,

      //child: Image.network(photo, fit: BoxFit.cover),
    );
  }
}
