import 'package:e9_report/signup.dart';
import 'package:e9_report/widgets.dart';
import 'package:e9_report/newsfeed.dart';
import 'package:e9_report/model.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              signInForm(context),
              hotLine(),
            ],
          ),
        ),
      ),
    );
  }
}

Widget signInForm(BuildContext context) => Expanded(
        child: SingleChildScrollView(
            child: Column(children: <Widget>[
      const SizedBox(height: 30),
      Image.asset('images/logo.png', width: 200, height: 200),
      const SizedBox(height: 12),
      const TextFieldNumberBorder('Số điện thoại'),
      const SizedBox(height: 16),
      const TextFieldPasswordBorder('Mật khẩu'),
      const SizedBox(height: 16),
      Row(
        children: [
          Expanded(
            child: TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/signup');
              },
              style: TextButton.styleFrom(
                  minimumSize: const Size(double.infinity, 60)),
              child: const Text('Đăng ký'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: ButtonReport(
                text: 'Đăng nhập',
                width: double.infinity,
                onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/newsfeed', (Route<dynamic> route) => false);
                }),
          ),
        ],
      ),
    ])));

Widget hotLine() => Align(
      alignment: Alignment.bottomCenter,
      child: RichText(
        text: TextSpan(
          text: 'Hotline: ',
          style: const TextStyle(fontSize: 16, color: Colors.black),
          children: [
            TextSpan(
              text: '18001186',
              style: const TextStyle(color: Colors.blue),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  print('Hotline tapped');
                },
            ),
          ],
        ),
      ),
    );
