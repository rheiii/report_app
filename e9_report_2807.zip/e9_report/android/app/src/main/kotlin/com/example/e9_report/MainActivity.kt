package com.example.e9_report

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
