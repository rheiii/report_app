package com.example.e9_signup_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
