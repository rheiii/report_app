import 'package:e9_signup_login/signup.dart';
import 'package:e9_signup_login/widgets.dart';
import 'package:e9_signup_login/newsfeed.dart';
import 'package:e9_signup_login/model.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              signInForm(context),
              hotLine(),
            ],
          ),
        ),
      ),
    );
  }
}

Widget signInForm(BuildContext context) => Expanded(
        child: SingleChildScrollView(
            child: Column(children: <Widget>[
      const SizedBox(height: 30),
      Image.asset('images/logo.png', width: 200, height: 200),
      const SizedBox(height: 12),
      const TextField(
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          labelText: 'Số điện thoại',
        ),
      ),
      const SizedBox(height: 16),
      const TextField(
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          labelText: 'Mật khẩu',
        ),
      ),
      const SizedBox(height: 16),
      Row(
        children: [
          TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/signup');
              },
              child: Text('Đăng ký')),
          Spacer(),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/newsfeed');
            },
            child: Text('Đăng nhập'),
            style: ElevatedButton.styleFrom(minimumSize: Size(140, 60)),
          ),
        ],
      ),
    ])));

Widget hotLine() => Align(
      alignment: Alignment.bottomCenter,
      child: RichText(
        text: TextSpan(
          text: 'Hotline: ',
          style: TextStyle(fontSize: 16, color: Colors.black),
          children: [
            TextSpan(
              text: '18001186',
              style: TextStyle(color: Colors.blue),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  print('Hotline tapped');
                },
            ),
          ],
        ),
      ),
    );
