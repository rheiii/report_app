import 'package:e9_signup_login/newsfeed.dart';
import 'package:e9_signup_login/policy.dart';
import 'package:e9_signup_login/signin.dart';
import 'package:e9_signup_login/signup.dart';
import 'package:e9_signup_login/profile.dart';
import 'package:e9_signup_login/report.dart';
import 'package:e9_signup_login/contact.dart';
import 'package:e9_signup_login/changepassword.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '',
      theme: ThemeData(
        //useMaterial3: true,
        primarySwatch: Colors.blue,
      ),
      //home: const SignInPage(),
      initialRoute: '/',
      routes: {
        '/': (context) => const SignInPage(),
        '/signup': (context) => const SignUpPage(),
        '/newsfeed': (context) => const NewsFeedPage(),
        '/profile': (context) => const ProfilePage(),
        '/contact': (context) => const ContactPage(),
        '/report': (context) => const ReportPage(),
        '/policy': (context) => const PolicyPage(),
        '/changepassword': (context) => const ChangePasswordPage(),
        '/logout': (context) => const SignInPage(),
      },
    );
  }
}
