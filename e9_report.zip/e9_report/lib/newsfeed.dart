import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:e9_signup_login/signin.dart';
import 'package:e9_signup_login/signup.dart';
import 'package:e9_signup_login/model.dart';
import 'package:e9_signup_login/widgets.dart';
import 'package:e9_signup_login/main.dart';

class NewsFeedPage extends StatefulWidget {
  const NewsFeedPage({Key? key}) : super(key: key);

  @override
  State<NewsFeedPage> createState() => _NewsFeedPageState();
}

class _NewsFeedPageState extends State<NewsFeedPage> {
  final posts = <Post>[];
  final users = <User>[];
  final menuList = <Menu>[];

  final menuSuCo = Menu('Sự cố', Icon(Icons.list), 'su-co', '/newsfeed');
  final menuBaoCao = Menu('Báo cáo', Icon(Icons.warning), 'bao-cao', '/report');
  final menuDoiMatKhau = Menu(
      'Đổi mật khẩu', Icon(Icons.password), 'doi-mat-khau', '/changepassword');
  final menuDieuKhoan =
      Menu('Điều khoản', Icon(Icons.description), 'dieu-khoan', '/policy');
  final menuLienHe =
      Menu('Liên hệ', Icon(Icons.contacts), 'lien-he', '/contact');
  final menuDangXuat = Menu('Đăng xuất', Icon(Icons.logout), 'dang-xuat', '/');

  @override
  void initState() {
    final user1 =
        User(username: 'Hoa', avatar: 'images/user1.png', phone: '0944556677');
    final user2 =
        User(username: 'Minh', avatar: 'images/user2.png', phone: '0927462165');
    users.addAll([user1, user2]);
    final status = ['Chờ xử lý', 'Đã xong', 'Không duyệt'];

    final post1 = Post(
        createdDate: '21/07/2022',
        title: 'Cửa thoát hiểm chung cư thường xuyên bị mở',
        content:
            'Mặc dù trần hành lang các tầng đã được chỉnh sửa trở lại ngay ngắn nhưng tình trạng cửa thoát hiểm tại một số tầng vẫn vô tư mở rộng, thậm chí được chèn chặt để gió không đẩy cửa khép vào.',
        photos: ['images/issue1.jpg'],
        status: status[0].toString(),
        user: user1);

    final post2 = Post(
        createdDate: '20/07/2022',
        title: 'Hầm gửi xe ngập nước',
        content:
            'Vào khoảng 9h sáng nay, đường ống nước tại dãy R1 của tầng hầm B3 bất ngờ gặp sự cố, khiến đường dẫn nước bị vỡ, nước chảy lênh láng xuống nền nhà.',
        photos: [
          'images/issue2a.png',
          'images/issue2b.png',
          'images/issue2c.png'
        ],
        status: status[1].toString(),
        user: user2);

    final post3 = Post(
        createdDate: '19/07/2022',
        title: 'Vỡ bể phốt tầng hầm B1',
        content:
            'Hệ thống bể phốt, nước thải sinh hoạt của tòa nhà từ khi xây dựng đến nay chưa được thông hút khiến bể phốt nứt vỡ ngấm vào bể ngầm chứa nước sinh hoạt.',
        photos: [],
        status: status[2].toString(),
        user: user1);

    final post4 = Post(
        createdDate: '19/07/2022',
        title: 'Khói cháy trên tầng 12',
        content:
            '10 giờ 50 phút, khói, lửa bao trùm một căn hộ ở block C, tầng 12. Về nguyên nhân cháy, có thể do một bé trai (12 tuổi) sinh sống ở căn hộ trên đã tự đốt ghế sofa, gây ra cháy.',
        photos: ['images/issue4a.jpg', 'images/issue4b.jpg'],
        status: status[1].toString(),
        user: user2);

    posts.addAll([post1, post2, post3, post4]);

    menuList.addAll([
      menuSuCo,
      menuBaoCao,
      menuDoiMatKhau,
      menuDieuKhoan,
      menuLienHe,
      menuDangXuat
    ]);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: true,
          title: const Text('Sự cố'),
        ),
        drawer: drawer(),
        body: postList(),
      ),
    );
  }

  Widget postList() {
    return ListView.builder(
      itemBuilder: (context, index) {
        final post = posts[index];
        return postItem(post);
      },
      itemCount: posts.length,
    );
  }

  Widget postItem(Post post) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      //padding: EdgeInsets.all(8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
              radius: 20,
              backgroundImage: AssetImage(post.user.avatar),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(post.user.username,
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(post.createdDate,
                        style: TextStyle(color: Colors.grey)),
                  ]),
            ),
            Text(
              post.status,
              style: TextStyle(color: statusColor(post.status)),
            ),
          ]),
          Divider(),
          Text(post.title, style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text(post.content),
          photoGrid(post.photos),
        ]),
      ),
    );
  }

  Color statusColor(String status) {
    if (status == 'Chờ xử lý') {
      return Colors.grey;
    } else if (status == 'Đã xong') {
      return Colors.green;
    } else {
      return Colors.red;
    }
  }

  Widget photoGrid(List<String> photos) {
    if (photos.isEmpty) {
      return Container();
    }
    var crossAxisCount = 4;
    if (photos.length == 1) {
      crossAxisCount = 1;
    } else if (photos.length == 2) {
      crossAxisCount = 2;
    } else if (photos.length == 3) {
      crossAxisCount = 3;
    }

    return GridView.builder(
      padding: EdgeInsets.only(top: 8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount, crossAxisSpacing: 4),
      itemBuilder: (context, index) {
        final photo = photos[index];
        return photoItem(photo);
      },
      itemCount: photos.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
    );
  }

  Widget photoItem(String photo) {
    return Container(
      //margin: EdgeInsets.only(top: 8),
      child: Image.network(photo, fit: BoxFit.cover),
    );
  }

  Widget drawer() {
    final userMenu = users[0];
    return Drawer(
        child: ListView(children: [
      drawerHeader(userMenu),
      Container(width: 200, height: 400, child: drawerMenu()),
    ]));
  }

  Widget drawerHeader(User user) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/profile');
      },
      child: Container(
        height: 120,
        padding: EdgeInsets.all(12),
        alignment: Alignment.bottomLeft,
        decoration: BoxDecoration(
          color: Colors.blue,
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: AssetImage(user.avatar),
          ),
          SizedBox(width: 12),
          Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.username,
                    style: TextStyle(fontSize: 16, color: Colors.white)),
                Text(user.phone, style: TextStyle(color: Colors.white)),
              ]),
        ]),
      ),
    );
  }

  Widget drawerMenu() {
    return ListView.separated(
      itemCount: menuList.length,
      separatorBuilder: (BuildContext context, int index) => const Divider(),
      itemBuilder: (BuildContext context, int index) {
        final menu = menuList[index];
        return drawMenuItem(menu);
      },
    );
  }

  Widget drawMenuItem(Menu menu) {
    return ListTile(
      leading: menu.icon,
      title: Text(
        menu.name,
      ),
      onTap: () {
        if (menu.route == '/') {
          Navigator.popUntil(context, ModalRoute.withName(menu.route));
        } else if (menu.route == '/newsfeed') {
          Navigator.pop(context);
        } else {
          Navigator.pushNamed(context, menu.route);
        }
      },
    );
  }
}
