import 'package:e9_report/changepassword.dart';
import 'package:e9_report/contact.dart';
import 'package:e9_report/newsfeed.dart';
import 'package:e9_report/policy.dart';
import 'package:e9_report/profile.dart';
import 'package:e9_report/report.dart';
import 'package:e9_report/signin.dart';
import 'package:e9_report/signup.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '',
        theme: ThemeData(
          //useMaterial3: true,
          colorScheme: ColorScheme.fromSwatch().copyWith(
            primary: Colors.cyan.shade500,
            secondary: Colors.cyan.shade500,
          ),
          //primaryColor: Colors.cyan.shade400,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => const SignInPage(),
          '/signup': (context) => const SignUpPage(),
          '/newsfeed': (context) => const NewsFeedPage(),
          '/profile': (context) => const ProfilePage(),
          '/contact': (context) => const ContactPage(),
          '/report': (context) => const ReportPage(),
          '/policy': (context) => const PolicyPage(),
          '/changepassword': (context) => const ChangePasswordPage(),
          '/logout': (context) => const SignInPage(),
        },
      ),
    );
  }
}
