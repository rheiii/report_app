import 'package:e9_report/signin.dart';
import 'package:e9_report/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key, this.title}) : super(key: key);

  final String? title;

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.blue,
        shadowColor: Colors.transparent,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        top: true,
        bottom: true,
        child: CustomScrollView(slivers: [
          SliverFillRemaining(
            hasScrollBody: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Expanded(child: signUpForm(context)),
                hotLine(),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}

Widget signUpForm(BuildContext context) {
  final TextEditingController sdt = TextEditingController();
  return Container(
    padding: EdgeInsets.all(16),
    child: Column(children: <Widget>[
      Image.asset('images/logo.png', width: 200, height: 200),
      const TextFieldNameBorder('Họ và tên'),
      const SizedBox(height: 12),
      TextFieldNumberBorder('Số điện thoại', sdt),
      const SizedBox(height: 16),
      const TextFieldPasswordBorder('Mật khẩu'),
      const SizedBox(height: 16),
      ButtonReport(
        text: 'Đăng ký',
        width: 200,
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    ]),
  );
}
