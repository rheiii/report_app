import 'package:flutter/material.dart';

class TextFieldBorder extends StatefulWidget {
  final String label;
  late TextEditingController? controller;

  TextFieldBorder({required this.label, this.controller});

  @override
  State<TextFieldBorder> createState() => _TextFieldBorderState();
}

class _TextFieldBorderState extends State<TextFieldBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

class TextFieldLargeBorder extends StatefulWidget {
  final String label;

  const TextFieldLargeBorder(this.label);

  @override
  State<TextFieldLargeBorder> createState() => _TextFieldLargeBorderState();
}

class _TextFieldLargeBorderState extends State<TextFieldLargeBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      minLines: 4,
      maxLines: 6,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

class TextFieldPasswordBorder extends StatefulWidget {
  final String label;

  const TextFieldPasswordBorder(this.label);

  @override
  State<TextFieldPasswordBorder> createState() =>
      _TextFieldPasswordBorderState();
}

class _TextFieldPasswordBorderState extends State<TextFieldPasswordBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      obscureText: true,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

class TextFieldNameBorder extends StatefulWidget {
  final String label;

  const TextFieldNameBorder(this.label);

  @override
  State<TextFieldNameBorder> createState() => _TextFieldNameBorderState();
}

class _TextFieldNameBorderState extends State<TextFieldNameBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      keyboardType: TextInputType.text,
      textCapitalization: TextCapitalization.words,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

class TextFieldNumberBorder extends StatefulWidget {
  final String label;
  TextEditingController? controller;
  TextFieldNumberBorder(this.label, this.controller, {Key? key})
      : super(key: key);

  @override
  State<TextFieldNumberBorder> createState() => _TextFieldNumberBorderState();
}

class _TextFieldNumberBorderState extends State<TextFieldNumberBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

// class TextFieldDateBorder extends StatefulWidget {
//   final String label;
//   TextEditingController? controller;
//   TextFieldDateBorder(this.label, this.controller, {Key? key})
//       : super(key: key);

//   @override
//   State<TextFieldDateBorder> createState() => _TextFieldDateBorderState();
// }

// class _TextFieldDateBorderState extends State<TextFieldDateBorder> {
//   @override
//   Widget build(BuildContext context) {

//   }
// }

class TextFieldEmailBorder extends StatefulWidget {
  final String label;

  const TextFieldEmailBorder(this.label);
  @override
  State<TextFieldEmailBorder> createState() => _TextFieldEmailBorderState();
}

class _TextFieldEmailBorderState extends State<TextFieldEmailBorder> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: widget.label,
      ),
    );
  }
}

class TextFieldTopLabelBorder extends StatefulWidget {
  final String label;

  const TextFieldTopLabelBorder(this.label);

  @override
  State<TextFieldTopLabelBorder> createState() =>
      _TextFieldTopLabelBorderState();
}

class _TextFieldTopLabelBorderState extends State<TextFieldTopLabelBorder> {
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(widget.label),
      const SizedBox(height: 8),
      const TextField(
        decoration: InputDecoration(
          border: OutlineInputBorder(),
        ),
      ),
    ]);
  }
}

class ButtonReport extends StatefulWidget {
  final String text;
  double width = double.infinity;
  double height = 60;
  final VoidCallback onPressed;

  ButtonReport(
      {super.key,
      required this.text,
      required this.width,
      this.height = 60,
      required this.onPressed});

  @override
  State<ButtonReport> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<ButtonReport> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () => widget.onPressed(),
      style: ElevatedButton.styleFrom(
          elevation: 0.0, minimumSize: Size(widget.width, widget.height)),
      child: Text(widget.text),
    );
  }
}
