import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: true,
        title: const Text('Liên hệ'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            contactDetails(),
            const SizedBox(height: 16),
            contactActions(),
            const SizedBox(height: 16),
            contactForm(),
          ]),
        ),
      ),
    );
  }

  Widget contactDetails() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: RichText(
        text: const TextSpan(
            style: TextStyle(fontSize: 16, height: 1.6, color: Colors.black),
            children: [
              TextSpan(
                  text: 'Địa chỉ: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: 'Vietnam\n'),
              TextSpan(
                  text: 'Hotline: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '0944556677 \n'),
              TextSpan(
                  text: 'Email: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: 'hoanguyen@mail.com'),
            ]),
      ),
    );
  }

  Widget contactActions() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
          border: Border.symmetric(
              horizontal: BorderSide(width: 1, color: Colors.grey.shade400))),
      child: Row(children: [
        Expanded(
          child: Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Column(children: const [
              Icon(Icons.mail, color: Colors.cyan),
              SizedBox(height: 4),
              Text(
                'Gửi email',
                style: TextStyle(fontSize: 16),
              ),
            ]),
          ),
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
                border: Border.symmetric(
                    vertical:
                        BorderSide(width: 1, color: Colors.grey.shade400))),
            alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Column(children: const [
              Icon(Icons.phone, color: Colors.cyan),
              SizedBox(height: 4),
              Text(
                'Gọi điện',
                style: TextStyle(fontSize: 16),
              ),
            ]),
          ),
        ),
        Expanded(
          child: Container(
            //alignment: Alignment.center,
            padding: const EdgeInsets.all(16),
            child: Center(
              child: Column(children: const [
                Icon(Icons.chat, color: Colors.cyan),
                SizedBox(height: 4),
                Text(
                  'Chat',
                  style: TextStyle(fontSize: 16),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget contactForm() => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const TextFieldTopLabelBorder('Nội dung phản hồi'),
            const SizedBox(height: 16),
            ButtonReport(
              text: 'Gửi',
              width: double.infinity,
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      );
}
