import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({Key? key}) : super(key: key);

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  final photos = <String>[];
  final String addphoto = ('images/add-photo.png');
  TextEditingController tieude = TextEditingController();

  @override
  void initState() {
    const String photo1 = ('images/issue2a.png');
    const String photo2 = ('images/issue2b.png');
    const String photo3 = ('images/issue2c.png');
    const String photo4 = ('images/issue4a.jpg');
    const String photo5 = ('images/issue4b.jpg');

    photos.addAll([photo1, photo2, photo3, photo4, photo5, addphoto]);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: true,
        title: const Text('Báo cáo'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextFieldBorder(label: 'Tiêu đề', controller: tieude),
              const SizedBox(height: 12),
              const TextFieldLargeBorder('Nội dung'),
              uploadPhoto(),
              const SizedBox(height: 8),
              ButtonReport(
                text: 'Lưu',
                width: double.infinity,
                onPressed: () {
                  setState(() {
                    Navigator.pop(context);
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget uploadPhoto() {
    var crossAxisCount = 4;
    return GridView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        childAspectRatio: 1.6666,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemBuilder: (context, index) {
        final photo = photos[index];
        return uploadPhotoItem(photo);
      },
      itemCount: photos.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
    );
  }

  Widget uploadPhotoItem(String photo) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Image.asset(
        photo,
        fit: BoxFit.cover,
        height: 162,
      ),

      // decoration: BoxDecoration(
      //   image: DecorationImage(
      //     image: AssetImage(photo),
      //     fit: BoxFit.cover,
      //   ),
      //   borderRadius: BorderRadius.circular(4),
      // ),

      //height: 162,

      //child: Image.network(photo, fit: BoxFit.cover),
    );
  }
}
