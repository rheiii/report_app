import 'package:flutter/material.dart';

class User {
  final String username;
  final String? birthday;
  final String? address;
  final String phone;
  final String? email;
  final String avatar;

  User(
      {required this.username,
      this.birthday,
      this.address,
      required this.phone,
      this.email,
      required this.avatar});
}

class Post {
  final String createdDate;
  final String title;
  final String content;
  final List<String> photos;
  final String status;
  final User user;

  Post(
      {required this.createdDate,
      required this.title,
      required this.content,
      required this.photos,
      required this.status,
      required this.user});
}

class Menu {
  final String name;
  final Widget icon;
  final String code;
  final String route;

  Menu(this.name, this.icon, this.code, this.route);
}




// class Status<String> {
//   final String status;

//   Status(this.status);
// }
// final pending = Status<String>('Chờ xử lý');
// final rejected = Status<String>('Không duyệt');
// final done = Status<String>('Đã xong');