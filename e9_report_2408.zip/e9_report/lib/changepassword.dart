import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';

class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({Key? key}) : super(key: key);

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: true,
        title: const Text('Đổi mật khẩu'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const TextFieldPasswordBorder('Mật khẩu cũ'),
              const SizedBox(height: 16),
              const TextFieldPasswordBorder('Mật khẩu mới'),
              const SizedBox(height: 16),
              const TextFieldPasswordBorder('Gõ lại mật khẩu mới'),
              const SizedBox(height: 16),
              ButtonReport(
                text: 'Lưu',
                width: double.infinity,
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
