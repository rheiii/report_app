import 'package:e9_report/widgets.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  //TextEditingController get controller => ngaysinh;
  final TextEditingController ngaysinh = TextEditingController();
  final TextEditingController diachi = TextEditingController();
  final TextEditingController sdt = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: true,
        title: const Text('Tài khoản'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              avatarEdit(),
              const SizedBox(height: 16),
              const TextFieldNameBorder('Họ và tên'),
              const SizedBox(height: 16),
              TextFieldBorder(label: 'Ngày sinh', controller: ngaysinh),
              const SizedBox(height: 16),
              TextFieldBorder(label: 'Địa chỉ', controller: diachi),
              const SizedBox(height: 16),
              TextFieldNumberBorder('Số điện thoại', sdt),
              const SizedBox(height: 16),
              const TextFieldEmailBorder('Email'),
              const SizedBox(height: 16),
              ButtonReport(
                text: 'Lưu',
                width: double.infinity,
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    print('${ngaysinh.text}, ${diachi.text}, ${sdt.text}');
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget avatarEdit() => Stack(children: [
        const CircleAvatar(
          radius: 40,
          backgroundImage: AssetImage('images/user1.png'),
        ),
        Positioned(
            bottom: 2,
            right: 2,
            child: Container(
              width: 28,
              height: 28,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.cyan,
              ),
              child: const Icon(
                Icons.photo_camera,
                size: 16,
                color: Colors.white,
              ),
            )),
      ]);
}
