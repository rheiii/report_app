import 'package:e9_report/model.dart';
import 'package:e9_report/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        //brightness: Brightness.light,
        elevation: 0,
        backgroundColor: Colors.white,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        top: true,
        bottom: true,
        child: CustomScrollView(slivers: [
          SliverFillRemaining(
            hasScrollBody: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Expanded(child: signInForm(context)),
                hotLine(),
              ],
            ),
          ),
          //),
          //),
        ]),
      ),
    );
  }
}

Widget signInForm(BuildContext context) {
  final TextEditingController sdt = TextEditingController();
  return Container(
    padding: EdgeInsets.all(16),
    child: Column(
      children: <Widget>[
        //const SizedBox(height: 20),
        Image.asset('images/logo.png', width: 200, height: 200),
        const SizedBox(height: 12),
        TextFieldNumberBorder('Số điện thoại', sdt),
        const SizedBox(height: 16),
        const TextFieldPasswordBorder('Mật khẩu'),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/signup');
                },
                style: TextButton.styleFrom(
                    minimumSize: const Size(double.infinity, 60)),
                child: const Text('Đăng ký'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ButtonReport(
                  text: 'Đăng nhập',
                  width: double.infinity,
                  onPressed: () {
                    print(sdt.text);
                    Navigator.pushReplacementNamed(context, '/newsfeed');
                  }),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget hotLine() => Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(16),
      child: RichText(
        text: TextSpan(
          text: 'Hotline: ',
          style: const TextStyle(fontSize: 16, color: Colors.black),
          children: [
            TextSpan(
              text: '18001186',
              style: const TextStyle(color: Colors.cyan),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  print('Hotline tapped');
                },
            ),
          ],
        ),
      ),
    );
